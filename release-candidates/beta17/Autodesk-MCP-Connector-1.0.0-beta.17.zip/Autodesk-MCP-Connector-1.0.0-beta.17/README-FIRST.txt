Autodesk MCP Connector 1.0.0-beta.17 — central-service pilot

This installer is for a pilot after your administrator deploys the central skill service.
Extract the ZIP completely. Save work and close Revit. Run INSTALL Autodesk MCP Connector.cmd, then restart Revit and AI clients.

Your administrator supplies skill-service-device.json beside the installer for this PC/user. Setup imports and encrypts it and removes that plaintext file after import. No GitHub account, Git installation or Git author commands are needed on team PCs.

Weekly skill submissions and approved skill downloads run in the background. You approve candidates through draft GitHub pull requests. Local skill edits are preserved. Shared guidance is also available to Claude through the Autodesk MCP workflow tools.

Without administrator enrollment, the connector can run but central skill sharing remains pending. Settings > Sharing service status and Open weekly skill log show the current state. Do not distribute any enrollment file publicly or reuse it across the team.
